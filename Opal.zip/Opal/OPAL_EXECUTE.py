#Opal1 Test file.
#$$hmm
print("text")
a = int(input("a:"))
a += 1
print(a)
y = 1
x = 1
y = x - 1
print(y, end="")
print(y, end="")
int(input(y))
#comment
print("text")#comment
print("text")#comment