import time
import sys
#Opal1 Test file.
print("MAIN MENU".center(40, "="))
#$$hmm
print("text")
a = int(input("a:"))
a += 1
print(a)
y = 1
x = 1
y = x - 1
print(y, end="")
print(y, end="")
int(input(y))
#comment
print("text") #comment
print("text") #comment
lists = ["item1", "item2"]
for i in range(5):
    print("loop")
    print("".join(lists))
    time.sleep(5)
    pass