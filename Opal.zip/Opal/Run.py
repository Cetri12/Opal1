#Opal1. 1.0 made 8/11/2026
#Modified ESPython Core for opal1 usage
import subprocess
from pathlib import Path
import os
import platform
import time
import sys

settings_path = Path(__file__).parent / "Core" / "OPAL_Settings.txt"

#File build data
Version = "Version: 1.0"
Build_Data = [Version, "Utility File", "Gen1"]

#Espython build data
OPAL_Version = "Version: 1.0"
OPAL_Build_Data = [OPAL_Version, "Gen1"]


if __name__ == "__main__":

    #Clears executable file and output.pys
    with open("OPAL_EXECUTE.py", "w") as f:
        pass
    
    output_path = Path("Core") / "output.opal1"
    with open(output_path, "w") as f:
        pass

    with open(settings_path, "r") as file:
        SETT = file.readline()

    if SETT[0] == "1": #Checks the setting for terminal feedback
        print("===Opal1===")
        print(Version)
        print("Please insert code.opal1 into folder. Dont worry if it's code.opal1.txt. It will work")
        OSTYPE = platform.system()
        print("OS:",OSTYPE)

    #Renames .esp.txt to .esp
    if Path("code.esp.txt").exists():
        os.rename("code.opal1.txt", "code.opal1")

    if Path("output.esp.txt").exists():
        os.rename("output.opal1.txt", "output.opal1")

    #Checks that the parser exists
    file_path = Path(__file__).parent / "Core" / "OPAL_Parser.py"
    if not file_path.exists():
        print()
        print("\033[31mError: Parser not found\033[0m")
        print()
    else:
        print()
        print("\033[34mParser Docked Sucessfully\033[0m")
        print()

    subprocess.run([sys.executable, file_path])