#Opal1 Parser. Modified 11/8/2026 for opal1 use. origianlly ESPython parser
import shutil
import sys
import subprocess
from pathlib import Path
import os
import time

LINES = [] #The individual lines
POS = 0 #Position in the line
READ = True #Tells the parser if it should read the code. off for comments and strings
DEPTH = 0 #Depth in the parenthesis
LCHAR = [] #line split into it's chars
STRIN = False #If the parser is in a string
GRID = [] #The list of each edited line. is re-inserted back into the file at the end.
COMMENT = False #Tracker to check if the parer is in a comment
runtime = "python" #The runtime of final executable

Version = "Version 0.1"

Build_Data = [Version,"Core File", "Gen1"]






def PARSE():
    global READ
    global DEPTH
    global POS
    global LCHAR
    global STRIN
    global GRID
    global COMMENT

    codepath = Path(__file__).parent / "code.opal1"

    with open(codepath, "r") as file:
        lines = file.readlines()

    for line in lines:
        LCHAR = list(line)
        POS = 0
        READ = True
        STRIN = False
        COMMENT = False

        while POS < len(LCHAR):

            if not COMMENT:
                if LCHAR[POS] == '"' or LCHAR[POS] == "'":
                    READ = not READ #Flips reading state
                    STRIN = not STRIN #Flips string mode

            if not COMMENT:
                if LCHAR[POS] == '\\' and LCHAR[POS+1] == '"':
                    print("Escaped qoute")
                    READ = not READ
                    STRIN = not STRIN

            if READ:
                if LCHAR[POS] == "#":
                    READ = False
                    COMMENT = True

            # $$ Comments
            if READ and STRIN == False and not COMMENT:
                if "".join(LCHAR[POS:POS+2]) == "$$":
                    del LCHAR[POS:POS+2]
                    LCHAR.insert(POS, "#")
                    POS += 2
                    READ = False #Turns off for the comment :D
                    COMMENT = True
                    continue

            # // Comments
            startingslash = False
            endingslash = False
            if READ and STRIN == False and not COMMENT:
                if line.startswith("//") and startingslash == False: 
                    startingslash = True
                    del LCHAR[POS:POS+2]
                    LCHAR.insert(POS, "#")
                    POS += 1
                    READ = False
                    COMMENT = True

                if "".join(LCHAR[POS:POS+3]) == ";//" and endingslash == False:
                    endingslash = True
                    del LCHAR[POS:POS+3]
                    LCHAR.insert(POS, " #")
                    POS += 1
                    READ = False
                    COMMENT = True

                if "".join(LCHAR[POS:POS+4]) == "; //" and endingslash == False:
                    endingslash = True
                    del LCHAR[POS:POS+4]
                    LCHAR.insert(POS, " #")
                    POS += 1
                    READ = False
                    COMMENT = True


            #Removing semicolons
            if READ and STRIN == False and not COMMENT:
                if POS <= len(LCHAR):
                    if LCHAR[POS] == ";":
                        del LCHAR[POS]
                        continue 



            #Incremental
            if READ and STRIN == False:
                if "".join(LCHAR[POS:POS+2]) == "++":
                    if not " = " in line:
                        del LCHAR[POS:POS+2]
                        LCHAR.insert(POS, " += 1")
                        POS += len(" += 1")
                        continue
                    else:
                        del LCHAR[POS:POS+2]
                        LCHAR.insert(POS, " - 1")
                        POS += len(" - 1")
            
            #Decremental
            if READ and STRIN == False and not COMMENT:
                if "".join(LCHAR[POS:POS+2]) == "--":
                    if not " = " in line:
                        del LCHAR[POS:POS+2]
                        LCHAR.insert(POS, " -= 1")
                        POS += len(" -= 1")
                        continue

                    else:
                        del LCHAR[POS:POS+2]
                        LCHAR.insert(POS, " + 1")
                        POS += len(" + 1")
            


            # else if
            if READ and STRIN == False and not COMMENT:
                if "".join(LCHAR[POS:POS+7]) == "else if":
                    del LCHAR[POS:POS+7]
                    LCHAR.insert(POS, "elif")
                    POS += 7
                    continue

            #unless
            if READ and STRIN == False and not COMMENT:
                if "".join(LCHAR[POS:POS+6]) == "unless":
                    del LCHAR[POS:POS+6]
                    LCHAR.insert(POS, "if not")
                    POS += 6
                    continue

            # && (logical and)
            if READ and STRIN == False and not COMMENT:
                if "".join(LCHAR[POS:POS+2]) == "&&":
                    del LCHAR[POS:POS+2]
                    LCHAR.insert(POS, "and")
                    POS += 3
                    continue 

            # || (logical or)
            if READ and STRIN == False and not COMMENT:
                if "".join(LCHAR[POS:POS+2]) == "||":
                    del LCHAR[POS:POS+2]
                    LCHAR.insert(POS, "or")
                    POS += 2
                    continue     

            # ! (logical not)
            if READ and STRIN == False and not COMMENT:
                if "".join(LCHAR[POS:POS+2]) == " !":
                    del LCHAR[POS:POS+2]
                    LCHAR.insert(POS, "not")
                    POS += 3
                    continue      

            # println()
            if READ and STRIN == False and not COMMENT:
                if "".join(LCHAR[POS:POS+7]) == "println":
                    del LCHAR[POS:POS+7]
                    LCHAR.insert(POS, "print")
                    POS += 5
                    continue    

            #out(). prints text without a newline
            #A horrible pain to code
            if READ and STRIN == False and not COMMENT:
                if "".join(LCHAR[POS:POS+4]) == "out(":
                    posahead = POS + 4
                    found = False

                    while posahead < len(LCHAR):
                        if LCHAR[posahead] == ")":
                            found = True
                            break
                        posahead += 1
                    
                    if found:
                        end = (', end="")')
                        LCHAR[posahead] = end
                        del LCHAR[POS:POS+4]
                        LCHAR[POS:POS] = "print("
                        POS = posahead + len(end) + 1
                        continue

            # null, NaN, nil, and nothing
            if READ and STRIN == False and not COMMENT:
                if "".join(LCHAR[POS:POS+3]) == "NaN" or "".join(LCHAR[POS:POS+3]) == "nil":
                    del LCHAR[POS:POS+3]

                if "".join(LCHAR[POS:POS+4]) == "Null":
                    del LCHAR[POS:POS+4]

                if "".join(LCHAR[POS:POS+7]) == "nothing":
                    del LCHAR[POS:POS+7]

                    LCHAR.insert(POS, "None")
                    POS += 4
                    continue

            #Lowercase booleans: true and false
            if READ and STRIN == False and not COMMENT:
                if "".join(LCHAR[POS:POS+4]) == "true":
                    del LCHAR[POS:POS+4]
                    LCHAR.insert(POS, "True")
                    POS += 4
                    continue

                elif "".join(LCHAR[POS:POS+5]) == "false":
                    del LCHAR[POS:POS+5]
                    LCHAR.insert(POS, "False")
                    POS += 5
                    continue          

            # name_is_main
            if READ and STRIN == False and not COMMENT:
                if "".join(LCHAR[POS:POS+12]) == "name_is_main":
                    del LCHAR[POS:POS+12]
                    LCHAR.insert(POS, '__name__ == "__main__"')
                    POS += 22
                    continue  

            #printf()
            if READ and STRIN == False and not COMMENT:
                if "".join(LCHAR[POS:POS+6]) == "printf(":
                    del LCHAR[POS:POS+6]
                    LCHAR.insert(POS, 'print(f')
                    POS += 7
                    continue  

            #delete --> del
            if READ and STRIN == False and not COMMENT:
                if "".join(LCHAR[POS:POS+6]) == "delete":
                    del LCHAR[POS:POS+6]
                    LCHAR.insert(POS, "del")
                    POS += 3
                    continue

            # intput( --> int(input(  
            #Easier to code than out(), but still a pain ;-;
            if READ and STRIN == False and not COMMENT:
                if "".join(LCHAR[POS:POS+7]) == "intput(":

                    iPOS = POS + 1
                    ifound = False
                    for i in LCHAR:
                        if i == ")" and ifound == False:
                            LCHAR.insert(iPOS, ")" )
                            ifound = True
                        iPOS += 1

                    del LCHAR[POS:POS+7]
                    LCHAR.insert(POS, "int(input(")
                    POS += 10
                    continue

            # floatput( --> float(input(  
            if READ and STRIN == False and not COMMENT:
                if "".join(LCHAR[POS:POS+8]) == "floatput(":

                    iPOS = POS + 1
                    ifound = False
                    for i in LCHAR:
                        if i == ")" and ifound == False:
                            LCHAR.insert(iPOS, ")" )
                            ifound = True
                        iPOS += 1

                    del LCHAR[POS:POS+8]
                    LCHAR.insert(POS, "float(input(")
                    POS += 12
                    continue

            #until --> while not
            if READ and STRIN == False and not COMMENT:
                if "".join(LCHAR[POS:POS+6]) == "untill":
                    del LCHAR[POS:POS+6]
                    LCHAR.insert(POS, "while not")
                    POS += 9
                    continue

            #debug
            if READ and STRIN == False and not COMMENT:
                if "".join(LCHAR[POS:POS+5]) == "debug":
                    del LCHAR[POS:POS+5]
                    LCHAR.insert(POS, 'print(f"DEBUG LAYER CONSOLE: {locals()}")')
                    POS += len(print(f"DEBUG LAYER CONSOLE: {locals()}"))
                    continue

            POS += 1
        GRID.append("".join(LCHAR))

    with open("output.opal1", "w") as file:
        for i in GRID:
            file.write(i)

if __name__ == "__main__":
    PARSE()
    codepath = Path(__file__).parent / "code.opal1"

    # copies output to PS_EXECUTE
    shutil.copyfile("output.opal1", "OPAL_EXECUTE.py")

    # Clears output.pys
    with open("output.opal1", "w") as file:
        pass

    print("\033[34mRunning...\033[0m")

    #Checks that the os is windows. If it is, terminal is cleared for execution
    time.sleep(1)
    if os.name == "nt":
        os.system("cls")

    #Deletes output.espython
    file_path = Path("output.opal1")
    file_path.unlink()

    #Auto execution
    settings_path = Path(__file__).parent / "OPAL_Settings.txt"
    execute_path = Path(__file__).parent.parent / "OPAL_EXECUTE.py"
    with open(settings_path, "r") as file:
        SETT = file.readlines()
        if "1" in SETT[1]: #Checks the setting for auto execution
            subprocess.run([runtime,execute_path])