#Opal Library folder unpackager 1.0 Made 9/5/2026-9/6/2026
#Taken from ESPython 1.07.05. no structural changes made, and this file is not really needed
from pathlib import Path
import sys

Version = "Version: 1.0"
Build_Data = [Version, "Type: Utility File", "Gen1"]

if __name__ == "__main__":
    print("===Unpackager===")
    folder = input("Name of folder: ")

    folder = Path(folder)
    print()
    print("Files:\033[35m")
    for file in folder.iterdir():
        if file.is_file():
            file_name = file.name
            print(file_name)
            filen = file.stem

        if file.suffix != ".txt":
            sys.path.append(folder)
            selfile = __import__(file)
            Build_Data = selfile.Build_Data
            if "Utility" in Build_Data[1]:
                file.rename(Path("Core") / file.name)

        if file.suffix == ".txt":
            if "tutorial" in str(file).lower():
                file.rename(Path("Core") / "Tutorials" / file.name)
            
            else:
                file.rename(Path("Core") / file.name)

        efolder = Path(folder)
        efolder.rmdir()

    print("\033[0m")

